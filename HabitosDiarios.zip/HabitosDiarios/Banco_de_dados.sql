create database HabitosDiarios;
use  HabitosDiarios;

create table habito(
	id INT auto_increment primary key,
    nome varchar(200),
    categoria varchar(200),
    meta_diaria int(10),
    progresso int (10)
);
