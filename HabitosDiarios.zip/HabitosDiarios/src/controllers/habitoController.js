const connection = require('../config/database');
const Habito = require('../models/habito');

class HabitoController {

    async listar(req, res) {
        try {
            
            const [rows] = await connection.query("SELECT * FROM habito");
            res.json(rows);
        } catch (err) {
            res.status(500).json({ erro: err.message });
        }
    }

    async buscar(req, res) {
        const id = req.params.id;

        const [rows] = await connection.query(
            "SELECT * FROM habito WHERE id = ?", 
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ erro: "Hábito não encontrado" });
        }

        res.json(rows[0]);
    }

    async criar(req, res) {
        const { nome, categoria, meta_diaria, progresso } = req.body;

        const [result] = await connection.query(
            "INSERT INTO habito (nome, categoria, meta_diaria, progresso) VALUES (?, ?, ?, ?)", 
            [nome, categoria, meta_diaria, progresso || 0] 
        );

        const habitoObjeto = new Habito( 
            result.insertId,
            nome,
            categoria,
            meta_diaria,
            progresso || 0
        );

        res.status(201).json(habitoObjeto);
    }

    async atualizar(req, res) {
        const id = req.params.id;
        const { nome, categoria, meta_diaria, progresso } = req.body;

        const [result] = await connection.query(
            "UPDATE habito SET nome=?, categoria=?, meta_diaria=?, progresso=? WHERE id=?", 
            [nome, categoria, meta_diaria, progresso, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ erro: "Hábito não encontrado" });
        }

        let mensagem = "Hábito atualizado";
        
        if (progresso >= meta_diaria) {
            mensagem = "Hábito concluído com sucesso! Parabéns!";
        }

        res.json({ mensagem: mensagem });
    }

    async deletar(req, res) {
        const id = req.params.id;

        const [result] = await connection.query(
            "DELETE FROM habito WHERE id=?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ erro: "Hábito não encontrado" });
        }

        res.status(204).send();
    }
}

module.exports = new HabitoController();