class habito{
    constructor(id,nome,categoria,meta_diaria,progresso){
        this.id = id
        this.nome = nome
        this.categoria = categoria
        this.meta_diaria = meta_diaria
        this.progresso = progresso
    }
}

module.exports = habito