const express = require('express')
const router = express.Router()

const habitoController = require('../controllers/habitoController')

router.get('/', habitoController.listar)
router.get('/:id', habitoController.buscar)
router.post('/', habitoController.criar)
router.put('/:id', habitoController.atualizar)
router.delete('/:id', habitoController.deletar)

module.exports = router